//import java.util.*;

public class KmerTuple { 
  public String kMer; 
  public int i; 
  
  public KmerTuple(String x, int y) { 
    this.kMer = x; 
    this.i = y; 
  } 
  
} 
