//import java.util.*;

public class DbResult {
	
	public int id;
	public String geneName;
	public String sequence;
	
	public DbResult(int id, String geneName, String sequence) {
		this.id = id;
		this.geneName = geneName;
		this.sequence = sequence;
	}
	
}