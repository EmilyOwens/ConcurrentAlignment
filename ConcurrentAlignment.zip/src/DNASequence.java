
public class DNASequence {
    
    public String name;
    public String sequence;
    
    public DNASequence(String myName, String mySequence){
        name = myName;
        sequence = mySequence;
    }
}
